importScripts("https://www.gstatic.com/firebasejs/8.2.1/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/8.2.1/firebase-messaging.js");
firebase.initializeApp({
  apiKey: "AIzaSyAejHtjXTOcsllTarDVCdIyLPdqzlr0HgI",
  authDomain: "push-notification-develo-4d9c6.firebaseapp.com",
  projectId: "push-notification-develo-4d9c6",
  storageBucket: "push-notification-develo-4d9c6.appspot.com",
  messagingSenderId: "428918133673",
  appId: "1:428918133673:web:1572995151d272ce4c6ab8",
  measurementId: "G-NRT6MZDC9X",
});
const messaging = firebase.messaging();
